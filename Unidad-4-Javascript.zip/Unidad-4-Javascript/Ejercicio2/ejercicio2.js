function Suma(){
    let valor1=document.getElementById('valor1').value;
    let valor2=document.getElementById('valor2').value;
    let resultado = parseInt(valor1)+parseInt(valor2)
    alert(resultado)

}