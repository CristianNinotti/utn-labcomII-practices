function funcion() {
    let valor1 = document.getElementById('valor1').value;
    alert(parseInt(valor1**3))
}