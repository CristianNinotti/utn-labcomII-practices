function cuenta(){
    let valor1 = document.getElementById('numero1').value;
    for(let i=0;i <= valor1; i++)
        {
            alert(i)
        }
        
}
